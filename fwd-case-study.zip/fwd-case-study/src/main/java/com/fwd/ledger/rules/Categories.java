package com.fwd.ledger.rules;

import jakarta.validation.constraints.NotBlank;

public record Categories(@NotBlank String transfer, @NotBlank String uncategorized) {
}
