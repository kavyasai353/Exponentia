package com.fwd.ledger.domain;

import java.math.BigDecimal;
import java.time.LocalDate;

public record RawTransaction(String id, long syncBatch, LocalDate date, Account account,
		String accountRaw, String merchant, String memo,
		BigDecimal amount) {
}
