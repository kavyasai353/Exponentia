package com.fwd.ledger.cli;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.fwd.ledger.LedgerService;
import com.fwd.ledger.TestRules;
import java.nio.file.Path;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.io.TempDir;
import org.springframework.boot.DefaultApplicationArguments;
import org.springframework.boot.test.system.CapturedOutput;
import org.springframework.boot.test.system.OutputCaptureExtension;

@ExtendWith(OutputCaptureExtension.class)
class LedgerCommandLineRunnerTest {

	private static final String USAGE =
			"Usage: java -jar ledger.jar --input=<transactions.csv> --output=<ledger_lines.csv>";

	@TempDir
	Path dir;

	private static int run(LedgerService service, String... args) {
		LedgerCommandLineRunner runner = new LedgerCommandLineRunner(service);
		runner.run(new DefaultApplicationArguments(args));
		return runner.getExitCode();
	}

	@Test
	void missingInputGivesUsage(CapturedOutput output) {
		assertThat(run(TestRules.service(), "--output=" + dir.resolve("out.csv"))).isEqualTo(1);
		assertThat(output.getErr()).contains(USAGE);
	}

	@Test
	void duplicatedOutputGivesUsage(CapturedOutput output) {
		int code = run(TestRules.service(), "--input=src/test/resources/feeds/transactions.csv",
				"--output=" + dir.resolve("a.csv"), "--output=" + dir.resolve("b.csv"));
		assertThat(code).isEqualTo(1);
		assertThat(output.getErr()).contains(USAGE);
		assertThat(dir.resolve("a.csv")).doesNotExist();
	}

	@Test
	void nonexistentInputFileFails(CapturedOutput output) {
		Path missing = dir.resolve("nope.csv");
		assertThat(run(TestRules.service(), "--input=" + missing, "--output=" + dir.resolve("out.csv")))
				.isEqualTo(1);
		assertThat(output.getErr()).contains("Input file not found: " + missing);
	}

	@Test
	void unexpectedRuntimeExceptionGivesOneLineOnStderrAndExitOne(CapturedOutput output) throws Exception {
		LedgerService service = mock(LedgerService.class);
		when(service.run(any(), any())).thenThrow(new IllegalStateException("boom"));
		int code = run(service, "--input=src/test/resources/feeds/transactions.csv",
				"--output=" + dir.resolve("out.csv"));
		assertThat(code).isEqualTo(1);
		assertThat(output.getErr()).contains("Unexpected error: boom");
	}

	@Test
	void successfulRunExitsZero() {
		int code = run(TestRules.service(), "--input=src/test/resources/feeds/transactions.csv",
				"--output=" + dir.resolve("out.csv"));
		assertThat(code).isZero();
		assertThat(dir.resolve("out.csv")).exists();
	}
}
