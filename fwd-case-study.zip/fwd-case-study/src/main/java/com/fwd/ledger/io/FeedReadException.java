package com.fwd.ledger.io;

import java.io.IOException;
import java.nio.file.Path;

public final class FeedReadException extends IOException {

	private static final long serialVersionUID = 1L;

	public FeedReadException(Path input, IOException cause) {
		super("Could not read input " + input + ": " + CauseMessage.of(cause), cause);
	}
}
