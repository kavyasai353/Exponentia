package com.fwd.ledger.rules;

import static org.assertj.core.api.Assertions.assertThat;

import com.fwd.ledger.TestRules;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;

class MerchantCatalogTest {

	private final MerchantCatalog catalog = TestRules.merchantCatalog();

	@Test
	void matchesByPrefixIgnoringSuffixes() {
		assertThat(catalog.categoryFor("SYSCO PHILA 8827")).contains("Food & beverage");
		assertThat(catalog.categoryFor("home depot #4102")).contains("Repairs & maintenance");
		assertThat(catalog.categoryFor("MAINLINE PROPERTIES LLC")).contains("Rent");
	}

	@Test
	void longestNameWins() {
		List<MerchantRule> rules = new ArrayList<>(TestRules.load().merchants());
		rules.add(new MerchantRule("SYSCO FOODS", "Test"));
		MerchantCatalog extended = new MerchantCatalog(rules);
		assertThat(extended.categoryFor("SYSCO FOODS 1")).contains("Test");
		assertThat(extended.categoryFor("SYSCO PHILA")).contains("Food & beverage");
	}

	@Test
	void unlistedMerchantIsEmpty() {
		assertThat(catalog.categoryFor("AMZN MKTP US*2K4X9")).isEmpty();
	}

	@Test
	void literalPrefixRuleMatchesSyscomart() {
		assertThat(catalog.categoryFor("SYSCOMART")).contains("Food & beverage");
	}

	@Test
	void blankIsEmpty() {
		assertThat(catalog.categoryFor("")).isEmpty();
		assertThat(catalog.categoryFor("   ")).isEmpty();
		assertThat(catalog.categoryFor(null)).isEmpty();
	}
}
