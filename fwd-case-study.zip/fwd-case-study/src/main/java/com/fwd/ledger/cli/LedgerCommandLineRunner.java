package com.fwd.ledger.cli;

import com.fwd.ledger.LedgerService;
import com.fwd.ledger.RunSummary;
import com.fwd.ledger.io.CauseMessage;
import com.fwd.ledger.io.FeedReadException;
import com.fwd.ledger.io.FeedValidationException;
import com.fwd.ledger.io.LedgerWriteException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.ExitCodeGenerator;

public final class LedgerCommandLineRunner implements ApplicationRunner, ExitCodeGenerator {

	private static final Logger log = LoggerFactory.getLogger(LedgerCommandLineRunner.class);

	private static final String USAGE =
			"Usage: java -jar ledger.jar --input=<transactions.csv> --output=<ledger_lines.csv>";

	private final LedgerService service;
	private int exitCode;

	public LedgerCommandLineRunner(LedgerService service) {
		this.service = service;
	}

	@Override
	public void run(ApplicationArguments args) {
		try {
			exitCode = execute(args);
		}
		catch (RuntimeException e) {
			log.error("Unexpected error", e);
			exitCode = fail("Unexpected error: " + CauseMessage.of(e));
		}
	}

	private int execute(ApplicationArguments args) {
		String inputArg = single(args, "input");
		String outputArg = single(args, "output");
		if (inputArg == null || outputArg == null) {
			return fail(USAGE);
		}
		Path input = Path.of(inputArg);
		Path output = Path.of(outputArg);
		if (!Files.isRegularFile(input)) {
			return fail("Input file not found: " + inputArg);
		}
		try {
			if (sameFile(input, output)) {
				return fail("--output must not be the same file as --input");
			}
		}
		catch (IOException e) {
			return fail("Could not check paths: " + CauseMessage.of(e));
		}
		try {
			RunSummary summary = service.run(input, output);
			summary.unknownAccountValues().forEach((value, count) -> log.warn(
					"Unknown account value '{}' on {} rows; those lines are flagged for review", value, count));
			log.info("Wrote {} ledger lines to {}: {} need review, {} duplicate rows dropped",
					summary.linesWritten(), outputArg, summary.needsReview(), summary.duplicatesDropped());
			return 0;
		}
		catch (FeedValidationException | FeedReadException | LedgerWriteException e) {
			return fail(e.getMessage());
		}
	}

	private static String single(ApplicationArguments args, String name) {
		List<String> values = args.getOptionValues(name);
		if (values == null || values.size() != 1 || values.get(0) == null || values.get(0).isBlank()) {
			return null;
		}
		return values.get(0);
	}

	private static boolean sameFile(Path input, Path output) throws IOException {
		Path realInput = input.toRealPath();
		Path other = Files.exists(output) ? output.toRealPath() : output.toAbsolutePath().normalize();
		return realInput.equals(other);
	}

	private static int fail(String message) {
		System.err.println(message);
		return 1;
	}

	@Override
	public int getExitCode() {
		return exitCode;
	}
}
