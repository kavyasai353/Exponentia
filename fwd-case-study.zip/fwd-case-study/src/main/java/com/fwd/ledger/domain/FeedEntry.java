package com.fwd.ledger.domain;

public record FeedEntry(RawTransaction transaction, boolean sameBatchConflict) {

	public static FeedEntry fresh(RawTransaction transaction) {
		return new FeedEntry(transaction, false);
	}

	public static FeedEntry conflicted(RawTransaction transaction) {
		return new FeedEntry(transaction, true);
	}
}
