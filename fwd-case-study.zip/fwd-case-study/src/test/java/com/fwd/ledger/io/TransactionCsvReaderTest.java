package com.fwd.ledger.io;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.jupiter.api.Assertions.assertThrows;

import com.fwd.ledger.domain.Account;
import com.fwd.ledger.domain.RawTransaction;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class TransactionCsvReaderTest {

	private static final String HEADER = "id,sync_batch,date,account,merchant,memo,amount\r\n";
	private static final String GOOD = "txn_1,1,2026-08-03,card,ACME,ACME,10.00\r\n";

	@TempDir
	Path dir;

	private final TransactionCsvReader reader = new TransactionCsvReader();

	private Path file(String content) throws IOException {
		Path p = dir.resolve("feed.csv");
		Files.writeString(p, content, StandardCharsets.UTF_8);
		return p;
	}

	private FeedValidationException invalid(String content) throws IOException {
		Path p = file(content);
		return assertThrows(FeedValidationException.class, () -> reader.read(p));
	}

	@Test
	void sampleFeedReadsSixtyRows() throws Exception {
		List<RawTransaction> rows = reader.read(Path.of("src/test/resources/feeds/transactions.csv"));
		assertThat(rows).hasSize(60);
	}

	@Test
	void wrongHeaderGivesOneErrorOnLineOne() throws Exception {
		FeedValidationException e = invalid("id,date,sync_batch,account,merchant,memo,amount\r\n" + GOOD);
		assertThat(e.errors()).hasSize(1);
		assertThat(e.errors().get(0).lineNumber()).isEqualTo(1);
		assertThat(e.getMessage()).startsWith("Invalid feed: 1 bad row")
				.contains("line 1: header \"id,date,sync_batch,account,merchant,memo,amount\" expected "
						+ "id,sync_batch,date,account,merchant,memo,amount");
	}

	@Test
	void quotedCommaAmountIsRejected() throws Exception {
		FeedValidationException e = invalid(HEADER + "txn_1,1,2026-08-03,card,ACME,ACME,\"12,40\"\r\n");
		assertThat(e.errors()).singleElement().satisfies(err -> {
			assertThat(err.field()).isEqualTo("amount");
			assertThat(err.value()).isEqualTo("12,40");
			assertThat(err.lineNumber()).isEqualTo(2);
		});
		assertThat(e.getMessage()).contains("line 2: amount \"12,40\" is not a valid amount (expected e.g. 62.40)");
	}

	@Test
	void tooManyDecimalsIsRejected() throws Exception {
		assertThat(invalid(HEADER + "txn_1,1,2026-08-03,card,ACME,ACME,1.005\r\n").errors())
				.singleElement().extracting(RowError::field).isEqualTo("amount");
	}

	@Test
	void leadingPlusIsRejected() throws Exception {
		assertThat(invalid(HEADER + "txn_1,1,2026-08-03,card,ACME,ACME,+5\r\n").errors())
				.singleElement().extracting(RowError::field).isEqualTo("amount");
	}

	@Test
	void blankIdIsRejected() throws Exception {
		assertThat(invalid(HEADER + " ,1,2026-08-03,card,ACME,ACME,5.00\r\n").errors())
				.singleElement().extracting(RowError::field).isEqualTo("id");
	}

	@Test
	void impossibleDateIsRejected() throws Exception {
		assertThat(invalid(HEADER + "txn_1,1,2026-13-01,card,ACME,ACME,5.00\r\n").errors())
				.singleElement().extracting(RowError::field).isEqualTo("date");
	}

	@Test
	void zeroSyncBatchIsRejected() throws Exception {
		assertThat(invalid(HEADER + "txn_1,0,2026-08-03,card,ACME,ACME,5.00\r\n").errors())
				.singleElement().extracting(RowError::field).isEqualTo("sync_batch");
	}

	@Test
	void wrongFieldCountIsRejected() throws Exception {
		FeedValidationException e = invalid(HEADER + "txn_1,1,2026-08-03,card\r\n");
		assertThat(e.errors()).singleElement().satisfies(err -> {
			assertThat(err.field()).isEqualTo("row");
			assertThat(err.reason()).isEqualTo("expected 7 fields, found 4");
		});
	}

	@Test
	void threeBadRowsGiveOneExceptionWithThreeErrors() throws Exception {
		FeedValidationException e = invalid(HEADER
				+ GOOD
				+ "txn_2,1,2026-08-03,card,ACME,ACME,\"12,40\"\r\n"
				+ ",1,2026-08-03,card,ACME,ACME,5.00\r\n"
				+ "txn_4,x,2026-08-03,card,ACME,ACME,5.00\r\n");
		assertThat(e.errors()).extracting(RowError::lineNumber).containsExactly(3L, 4L, 5L);
		assertThat(e.errors()).extracting(RowError::field).containsExactly("amount", "id", "sync_batch");
		assertThat(e.getMessage()).startsWith("Invalid feed: 3 bad rows");
	}

	@Test
	void quotedMerchantWithCommaIsOneField() throws Exception {
		List<RawTransaction> rows = reader.read(file(HEADER + "txn_1,1,2026-08-03,card,\"SYSCO, INC\",memo,5.00\r\n"));
		assertThat(rows).singleElement().satisfies(r -> {
			assertThat(r.merchant()).isEqualTo("SYSCO, INC");
			assertThat(r.memo()).isEqualTo("memo");
		});
	}

	@Test
	void unknownAccountKeepsRawValue() throws Exception {
		List<RawTransaction> rows = reader.read(file(HEADER + "txn_1,1,2026-08-03,savings,ACME,ACME,5.00\r\n"));
		assertThat(rows).singleElement().satisfies(r -> {
			assertThat(r.account()).isEqualTo(Account.UNKNOWN);
			assertThat(r.accountRaw()).isEqualTo("savings");
		});
	}

	@Test
	void leadingByteOrderMarkIsIgnored() throws Exception {
		List<RawTransaction> rows = reader.read(file("﻿" + HEADER + GOOD));
		assertThat(rows).hasSize(1);
	}

	@Test
	void missingFileIsAReadException() {
		assertThatThrownBy(() -> reader.read(dir.resolve("nope.csv"))).isInstanceOf(FeedReadException.class)
				.hasMessageStartingWith("Could not read input " + dir.resolve("nope.csv") + ": ");
	}

	@Test
	void emptyFileIsAValidationErrorOnTheHeader() throws Exception {
		FeedValidationException e = invalid("");
		assertThat(e.errors()).singleElement().satisfies(err -> {
			assertThat(err.field()).isEqualTo("header");
			assertThat(err.lineNumber()).isEqualTo(1);
		});
	}

	@Test
	void headerOnlyFileGivesZeroRows() throws Exception {
		assertThat(reader.read(file(HEADER))).isEmpty();
	}

	@Test
	void unclosedQuoteIsAFeedReadException() throws Exception {
		Path p = file(HEADER + "txn_1,1,2026-08-03,card,\"ACME,ACME,10.00\r\n");
		assertThatThrownBy(() -> reader.read(p)).isInstanceOf(FeedReadException.class)
				.hasMessageStartingWith("Could not read input " + p + ": ");
	}

	@Test
	void amountWithoutLeadingDigitIsRejected() throws Exception {
		assertThat(invalid(HEADER + "txn_1,1,2026-08-03,card,ACME,ACME,.5\r\n").errors())
				.singleElement().extracting(RowError::field).isEqualTo("amount");
	}

	@Test
	void amountWithoutTrailingDigitsIsRejected() throws Exception {
		assertThat(invalid(HEADER + "txn_1,1,2026-08-03,card,ACME,ACME,5.\r\n").errors())
				.singleElement().extracting(RowError::field).isEqualTo("amount");
	}

	@Test
	void negativeZeroIsAcceptedAsZero() throws Exception {
		List<RawTransaction> rows = reader.read(file(HEADER + "txn_1,1,2026-08-03,card,ACME,ACME,-0\r\n"));
		assertThat(rows).singleElement().satisfies(r -> assertThat(r.amount()).isEqualByComparingTo("0"));
	}
}
