package com.fwd.ledger.io;

/** One place for "the cause's message, or its class name if it has none". */
public final class CauseMessage {

	private CauseMessage() {
	}

	public static String of(Throwable cause) {
		return cause.getMessage() != null ? cause.getMessage() : cause.getClass().getSimpleName();
	}
}
