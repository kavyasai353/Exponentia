package com.fwd.ledger;

import com.fwd.ledger.domain.Account;
import com.fwd.ledger.domain.DedupResult;
import com.fwd.ledger.domain.FeedEntry;
import com.fwd.ledger.domain.LedgerLine;
import com.fwd.ledger.domain.RawTransaction;
import com.fwd.ledger.io.FeedReadException;
import com.fwd.ledger.io.FeedValidationException;
import com.fwd.ledger.io.LedgerCsvWriter;
import com.fwd.ledger.io.LedgerWriteException;
import com.fwd.ledger.io.TransactionCsvReader;
import com.fwd.ledger.rules.FeedDeduplicator;
import com.fwd.ledger.rules.TransactionClassifier;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.SortedMap;
import java.util.TreeMap;

public final class LedgerService {

	private final TransactionCsvReader reader;
	private final FeedDeduplicator deduplicator;
	private final TransactionClassifier classifier;
	private final LedgerCsvWriter writer;

	public LedgerService(TransactionCsvReader reader, FeedDeduplicator deduplicator,
			TransactionClassifier classifier, LedgerCsvWriter writer) {
		this.reader = reader;
		this.deduplicator = deduplicator;
		this.classifier = classifier;
		this.writer = writer;
	}

	public RunSummary run(Path input, Path output)
			throws FeedReadException, FeedValidationException, LedgerWriteException {
		List<RawTransaction> rows = reader.read(input);
		DedupResult dedup = deduplicator.deduplicate(rows);
		List<LedgerLine> lines = new ArrayList<>();
		SortedMap<String, Integer> unknownAccounts = new TreeMap<>();
		int needsReview = 0;
		for (FeedEntry entry : dedup.entries()) {
			LedgerLine line = classifier.classify(entry);
			lines.add(line);
			if (line.needsReview()) {
				needsReview++;
			}
			RawTransaction tx = entry.transaction();
			if (tx.account() == Account.UNKNOWN) {
				unknownAccounts.merge(Account.normalizeFeedValue(tx.accountRaw()), 1, Integer::sum);
			}
		}
		writer.write(lines, output);
		return new RunSummary(lines.size(), needsReview, dedup.duplicatesDropped(), unknownAccounts);
	}
}
