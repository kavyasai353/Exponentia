package com.fwd.ledger.rules;

import com.fwd.ledger.domain.Account;
import com.fwd.ledger.domain.Direction;
import com.fwd.ledger.domain.TextNormalizer;
import java.math.BigDecimal;
import java.util.List;

public final class TransferMatcher {

	private record Pattern(String text, Account account, Direction direction) {
	}

	private final List<Pattern> patterns;

	public TransferMatcher(List<TransferPatternRule> rules) {
		this.patterns = rules.stream()
				.map(r -> new Pattern(TextNormalizer.normalize(r.text()), r.account(), r.direction()))
				.filter(p -> !p.text().isEmpty())
				.toList();
	}

	public boolean contains(String memo) {
		String normalized = TextNormalizer.normalize(memo);
		return patterns.stream().anyMatch(p -> normalized.contains(p.text()));
	}

	public boolean fits(String memo, Account account, BigDecimal amount) {
		String normalized = TextNormalizer.normalize(memo);
		return patterns.stream().anyMatch(p -> normalized.contains(p.text())
				&& p.account() == account && p.direction().matches(amount));
	}
}
