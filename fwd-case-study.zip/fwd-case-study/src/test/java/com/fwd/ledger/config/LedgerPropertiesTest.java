package com.fwd.ledger.config;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.fwd.ledger.TestRules;
import com.fwd.ledger.domain.Account;
import com.fwd.ledger.domain.Direction;
import com.fwd.ledger.rules.Categories;
import com.fwd.ledger.rules.MerchantRule;
import com.fwd.ledger.rules.TransferPatternRule;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import java.util.List;
import java.util.Set;
import org.junit.jupiter.api.Test;

class LedgerPropertiesTest {

	private static final List<TransferPatternRule> PATTERNS =
			List.of(new TransferPatternRule("X", Account.BANK, Direction.OUT));

	private static LedgerProperties props(Categories categories, List<TransferPatternRule> patterns,
			List<MerchantRule> merchants) {
		return new LedgerProperties(categories, patterns, "PENDING", merchants);
	}

	@Test
	void duplicateMerchantAfterNormalizationIsRejected() {
		assertThatThrownBy(() -> props(new Categories("T", "U"), PATTERNS,
				List.of(new MerchantRule("SYSCO", "a"), new MerchantRule(" sysco ", "b"))))
				.isInstanceOf(IllegalArgumentException.class)
				.hasMessage("Duplicate merchant name in ledger.merchants: SYSCO");
	}

	@Test
	void unknownAccountPatternIsRejected() {
		assertThatThrownBy(() -> props(new Categories("T", "U"),
				List.of(new TransferPatternRule("FOO", Account.UNKNOWN, Direction.IN)),
				List.of(new MerchantRule("SYSCO", "a"))))
				.isInstanceOf(IllegalArgumentException.class)
				.hasMessage("Transfer pattern 'FOO' must use account card or bank");
	}

	@Test
	void blankCategoryNameGivesOneViolation() {
		Validator validator = Validation.buildDefaultValidatorFactory().getValidator();
		LedgerProperties p = props(new Categories(" ", "U"), PATTERNS, List.of(new MerchantRule("SYSCO", "a")));
		Set<ConstraintViolation<LedgerProperties>> violations = validator.validate(p);
		assertThat(violations).hasSize(1);
	}

	@Test
	void nullListsAreLeftToBeanValidation() {
		Validator validator = Validation.buildDefaultValidatorFactory().getValidator();
		LedgerProperties p = props(new Categories("T", "U"), null, null);
		assertThat(validator.validate(p)).hasSize(2);
	}

	@Test
	void shippedConfigBindsAndIsValid() {
		Validator validator = Validation.buildDefaultValidatorFactory().getValidator();
		LedgerProperties p = TestRules.load();
		assertThat(validator.validate(p)).isEmpty();
		assertThat(p.merchants()).hasSize(16);
		assertThat(p.transferPatterns()).hasSize(4);
	}
}
