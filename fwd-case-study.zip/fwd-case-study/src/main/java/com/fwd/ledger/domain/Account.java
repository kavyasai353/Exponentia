package com.fwd.ledger.domain;

import java.util.Locale;

public enum Account {
	CARD, BANK, UNKNOWN;

	/** The one definition of how a raw account value from the feed is compared and counted. */
	public static String normalizeFeedValue(String raw) {
		return raw == null ? "" : raw.trim().toLowerCase(Locale.ROOT);
	}

	public static Account fromFeed(String raw) {
		return switch (normalizeFeedValue(raw)) {
			case "card" -> CARD;
			case "bank" -> BANK;
			default -> UNKNOWN;
		};
	}
}
