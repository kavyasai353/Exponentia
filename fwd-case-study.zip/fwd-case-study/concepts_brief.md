# EXP-412 Story 1: Ingest the feed and produce ledger lines

* **Author:** Kavya
* **Date:** 2026-11-06

## Overview

A restaurant operator has a corporate card and a business bank account. A provider sends
us one CSV of raw transactions from both (`transactions.csv`, columns `id, sync_batch,
date, account, merchant, memo, amount`). Story 1 turns that feed into one categorized
ledger line per transaction (`ledger_lines.csv`, columns `transaction_id, date, type,
category, amount, needs_review`). A person later reviews the lines we're unsure about
(Story 3), so our job is to be right when we're confident and to flag the rest.

The rules are fixed by the story (the case study brief). This brief covers
how we apply them and the gaps the story leaves open.

Stack (decided): Java 21, Spring Boot 4.1.2, Maven
Wrapper, run as a command-line app: `./mvnw spring-boot:run -Dspring-boot.run.arguments="--input=... --output=..."`
or `java -jar`.

Sample data: `src/test/resources/feeds/transactions.csv` (60 rows, 56 unique ids) and
`src/test/resources/feeds/expected_first_15.csv`.

## Analysis

**The guiding principle: when unsure, send it to review.** A wrong category a person
looks at costs a minute. A wrong category nobody looks at (`needs_review = false`) ends
up in the books. So every gap below is resolved toward `needs_review = true`, never
toward a silent guess.

**Gap 1: the transfer rule as written catches rent.** The story says a transfer's memo
"will say PAYMENT or TRANSFER". But `txn_1022`, rent to MAINLINE PROPERTIES, has the memo
`ACH PAYMENT MAINLINE PROPERTIES`. Matching on the word PAYMENT would book a $6,500 rent
payment as a transfer with `needs_review = false`, hiding a real expense. The real
transfers in the data look like this:

| id | account | merchant | memo | amount |
|---|---|---|---|---|
| txn_1016 | bank | ONLINE PAYMENT TO CARD 4421 | ONLINE PAYMENT TO CARD 4421 | 4850.00 |
| txn_1017 | card | PAYMENT RECEIVED | ONLINE PAYMENT - THANK YOU | -4850.00 |
| txn_1027 | bank | TRANSFER TO SAVINGS 8810 | ONLINE TRANSFER TO SAVINGS 8810 | 10000.00 |
| txn_1040 | bank | TRANSFER FROM SAVINGS 8810 | ONLINE TRANSFER FROM SAVINGS 8810 | -5000.00 |
| txn_1051/1052 | bank/card | (same shape as 1016/1017) | | 6200.00 / -6200.00 |

Proposed: transfer detection uses a configured list of patterns (for example
`PAYMENT TO CARD`, `PAYMENT - THANK YOU`, `TRANSFER TO SAVINGS`, `TRANSFER FROM SAVINGS`)
matched against the memo, case-insensitive. A pattern miss is the safe failure: an
unknown transfer becomes `Uncategorized` with `needs_review = true`. A broad keyword hit
is the unsafe failure: an expense disappears.

**Gap 2: pending vs posted.** `txn_1020` is a $1.00 pending hold in batch 1 and $62.40
posted in batch 2. Four ids repeat. Keep the row from the highest `sync_batch` and drop
the others completely (its amount, memo and date all come from that row).

**Gap 3: things the story doesn't say.** Proposed answers:
- Same id and same `sync_batch` twice: if the rows are identical, keep one. If they
  differ, keep the last one in file order and set `needs_review = true`.
- Two list names both match the start of a merchant: the longest one wins.
- Prefix matching is literal, as the story says (`SYSCOMART` would match `SYSCO`). We
  note the risk and don't add word-boundary rules the story didn't ask for.
- Zero amount: book it as a purchase with `needs_review = true`.
- Malformed rows (missing id, bad amount, bad date, unknown account): the run fails and
  lists every bad row with its line number. A ledger that silently drops a row is
  worse than no ledger.
- Output order: the order each id first appears in the feed. Output is written to a
  temp file and moved into place, so a failed run never leaves a half-written ledger.
- Amounts keep their sign and two decimals exactly as in the feed (refunds and deposits
  stay negative, as in `expected_first_15.csv`). Money is `BigDecimal`, never `double`.

**Rule order** (first match wins):
1. Memo matches a transfer pattern → `transfer`, `Transfer`, `needs_review = false`.
2. Card account, negative amount → `refund`, category from the merchant list.
3. Bank account, negative amount → `deposit`, category from the merchant list.
4. Anything else → `purchase`, category from the merchant list.

In steps 2 to 4, a merchant not on the list gets `Uncategorized` and `needs_review = true`.

**Nothing hardcoded.** The merchant list and the transfer patterns live in
`application.yml`, bound to typed `@ConfigurationProperties` records and validated at
startup (no empty names, no duplicate names). Adding a merchant is a config change.

**Shape of the code.** One job per class so each rule can be tested on its own:
- a CSV reader that turns rows into `RawTransaction` records and collects validation errors
- a deduplicator that keeps the highest `sync_batch` per id
- a merchant categorizer (prefix match against the configured list)
- a transaction classifier that applies the rule order above
- a CSV writer for `LedgerLine` records
- a thin command-line runner that wires these together and prints a summary (lines
  written, how many need review)

The classifier and categorizer don't know about CSV or Spring, so Story 3 (review queue)
and the later LLM step can reuse them behind a different entry point.

## Goals vs. Non-Goals

* **In-Scope Goals:**
  * Read `transactions.csv`, write `ledger_lines.csv` with the exact columns and formats
    of `expected_first_15.csv`.
  * Dedup by highest `sync_batch`.
  * Classify type and category by the rules above; flag uncertain lines.
  * Config-driven merchant list and transfer patterns.
  * Unit tests per rule, and an end-to-end test against a full expected output for all
    56 ids (the first 15 rows checked against the provided file).
* **Out-of-Scope Non-Goals:**
  * Story 2 (splitting one transaction across two categories) and Story 3 (review queue).
  * The LLM categorization step.
  * A database, a REST API, multiple operators, currency handling.
  * Matching the two legs of a transfer to each other.

## Alternatives Weighed

* **Transfer = memo contains PAYMENT or TRANSFER (the story's literal wording).**
  Rejected by author: it books rent (`txn_1022`) as a transfer and hides a $6,500 expense.
* **Check the merchant list first, then the transfer keywords.** This fixes rent, but
  an unlisted vendor paid by ACH ("ACH PAYMENT NEW VENDOR") would still become a
  transfer that nobody reviews. Rejected by author: it fails silently.
* **Pair the two legs of each transfer by amount and date.** Rejected by author: the
  savings account isn't in the feed, so savings moves have only one leg. It also adds
  matching logic the story doesn't ask for.
* **Hand-rolled `String.split(",")` CSV parsing.** Rejected by author: it breaks on
  quoted fields with commas. Use Apache Commons CSV, which is small and mature.
* **Skip bad rows and keep going.** Rejected by author: dropping money from a ledger
  without anyone noticing is the worst outcome for a bookkeeper.
* **Merchant list in a Java enum or map.** Rejected by author: every new merchant would
  need a code change and a deploy.

## Key Decisions & Staging for Next Steps

* Rule order and tight transfer patterns as above (Gap 1).
* Highest `sync_batch` wins; same-batch conflicts are flagged (Gaps 2, 3).
* Fail the whole run on malformed input, listing every error.
* Config-driven rules, validated at startup.
* Next: turn this into a design document and review it before any code is written.
