package com.fwd.ledger.domain;

import java.util.List;

public record DedupResult(List<FeedEntry> entries, int duplicatesDropped) {

	public DedupResult {
		entries = List.copyOf(entries);
	}
}
