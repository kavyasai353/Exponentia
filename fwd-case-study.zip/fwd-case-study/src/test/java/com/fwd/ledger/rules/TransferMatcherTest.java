package com.fwd.ledger.rules;

import static org.assertj.core.api.Assertions.assertThat;

import com.fwd.ledger.TestRules;
import com.fwd.ledger.domain.Account;
import java.math.BigDecimal;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

class TransferMatcherTest {

	private final TransferMatcher matcher = TestRules.transferMatcher();

	@ParameterizedTest
	@CsvSource({
			"ONLINE PAYMENT TO CARD 4421, BANK, 4850.00",
			"ONLINE PAYMENT - THANK YOU, CARD, -4850.00",
			"ONLINE TRANSFER TO SAVINGS 8810, BANK, 10000.00",
			"ONLINE TRANSFER FROM SAVINGS 8810, BANK, -5000.00"
	})
	void sampleTransfersContainAndFit(String memo, Account account, BigDecimal amount) {
		assertThat(matcher.contains(memo)).isTrue();
		assertThat(matcher.fits(memo, account, amount)).isTrue();
	}

	@ParameterizedTest
	@CsvSource({
			"ACH PAYMENT MAINLINE PROPERTIES",
			"GUSTO PAYROLL",
			"AUTOPAY COMCAST BUSINESS"
	})
	void nonTransferMemosAreNotContained(String memo) {
		assertThat(matcher.contains(memo)).isFalse();
	}

	@Test
	void wrongAccountOrSignDoesNotFit() {
		assertThat(matcher.contains("ONLINE PAYMENT - THANK YOU")).isTrue();
		assertThat(matcher.fits("ONLINE PAYMENT - THANK YOU", Account.BANK, new BigDecimal("100.00"))).isFalse();
		assertThat(matcher.fits("ONLINE PAYMENT - THANK YOU", Account.CARD, new BigDecimal("100.00"))).isFalse();
		assertThat(matcher.fits("ONLINE PAYMENT - THANK YOU", Account.UNKNOWN, new BigDecimal("-100.00"))).isFalse();
	}

	@Test
	void zeroAmountFitsNothing() {
		assertThat(matcher.fits("PAYMENT TO CARD 4421", Account.BANK, BigDecimal.ZERO)).isFalse();
	}

	@Test
	void caseAndSpacingAreIgnored() {
		assertThat(matcher.contains("  online   payment  -  thank you ")).isTrue();
		assertThat(matcher.contains("online   payment to   card 4421")).isTrue();
		assertThat(matcher.fits("online transfer  to savings", Account.BANK, new BigDecimal("1.00"))).isTrue();
	}

	@Test
	void blankMemoNeverMatches() {
		assertThat(matcher.contains("")).isFalse();
		assertThat(matcher.contains(null)).isFalse();
		assertThat(matcher.fits("  ", Account.BANK, BigDecimal.ONE)).isFalse();
	}
}
