package com.fwd.ledger.io;

import com.fwd.ledger.domain.Account;
import com.fwd.ledger.domain.RawTransaction;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.csv.DuplicateHeaderMode;

public final class TransactionCsvReader {

	private static final List<String> HEADER = List.of("id", "sync_batch", "date", "account", "merchant", "memo",
			"amount");
	private static final Pattern AMOUNT = Pattern.compile("-?\\d+(\\.\\d{1,2})?");
	private static final char BOM = '﻿';

	private static final CSVFormat FORMAT = CSVFormat.DEFAULT.builder()
			.setHeader()
			.setSkipHeaderRecord(true)
			.setTrim(true)
			.setIgnoreEmptyLines(true)
			.setAllowMissingColumnNames(true)
			.setDuplicateHeaderMode(DuplicateHeaderMode.ALLOW_ALL)
			.get();

	private record NumberedRecord(long line, CSVRecord record) {
	}

	public List<RawTransaction> read(Path input) throws FeedReadException, FeedValidationException {
		try (BufferedReader reader = Files.newBufferedReader(input, StandardCharsets.UTF_8)) {
			reader.mark(1);
			if (reader.read() != BOM) {
				reader.reset();
			}
			try (CSVParser parser = FORMAT.parse(reader)) {
				List<String> actual = parser.getHeaderNames();
				if (!actual.equals(HEADER)) {
					String shown = String.join(",", actual);
					throw new FeedValidationException(List.of(new RowError(1, "header", shown,
							"expected " + String.join(",", HEADER))));
				}
				return convert(readRecords(parser));
			}
		}
		catch (IOException e) {
			throw new FeedReadException(input, e);
		}
	}

	/** Only the parser's own iteration is guarded: that is where commons-csv reports a malformed file. */
	private static List<NumberedRecord> readRecords(CSVParser parser) throws IOException {
		List<NumberedRecord> records = new ArrayList<>();
		try {
			for (CSVRecord record : parser) {
				records.add(new NumberedRecord(parser.getCurrentLineNumber(), record));
			}
		}
		catch (UncheckedIOException e) {
			throw e.getCause();
		}
		catch (IllegalStateException | IllegalArgumentException e) {
			// malformed CSV (for example a quote that never closes)
			throw new IOException(e.getMessage(), e);
		}
		return records;
	}

	private static List<RawTransaction> convert(List<NumberedRecord> records) throws FeedValidationException {
		List<RawTransaction> rows = new ArrayList<>();
		List<RowError> errors = new ArrayList<>();
		for (NumberedRecord numbered : records) {
			CSVRecord record = numbered.record();
			long line = numbered.line();
			if (record.size() != HEADER.size()) {
				errors.add(new RowError(line, "row", "", "expected " + HEADER.size() + " fields, found "
						+ record.size()));
				continue;
			}
			String id = record.get("id");
			boolean idValid = !id.isBlank();
			if (!idValid) {
				errors.add(new RowError(line, "id", "", "is blank"));
			}
			Long batch = parseBatch(record.get("sync_batch"), line, errors);
			LocalDate date = parseDate(record.get("date"), line, errors);
			BigDecimal amount = parseAmount(record.get("amount"), line, errors);
			boolean valid = idValid && batch != null && date != null && amount != null;
			if (valid) {
				String accountRaw = record.get("account");
				rows.add(new RawTransaction(id, batch, date, Account.fromFeed(accountRaw), accountRaw,
						record.get("merchant"), record.get("memo"), amount));
			}
		}
		if (!errors.isEmpty()) {
			throw new FeedValidationException(errors);
		}
		return rows;
	}

	private static Long parseBatch(String value, long line, List<RowError> errors) {
		Long batch = null;
		try {
			batch = Long.parseLong(value);
		}
		catch (NumberFormatException e) {
			// reported below, with the same text as a non-positive number
		}
		if (batch == null || batch <= 0) {
			errors.add(new RowError(line, "sync_batch", value, "is not a positive whole number"));
			return null;
		}
		return batch;
	}

	private static LocalDate parseDate(String value, long line, List<RowError> errors) {
		try {
			return LocalDate.parse(value);
		}
		catch (DateTimeParseException e) {
			errors.add(new RowError(line, "date", value, "is not a valid date (expected yyyy-MM-dd)"));
			return null;
		}
	}

	private static BigDecimal parseAmount(String value, long line, List<RowError> errors) {
		if (!AMOUNT.matcher(value).matches()) {
			errors.add(new RowError(line, "amount", value, "is not a valid amount (expected e.g. 62.40)"));
			return null;
		}
		return new BigDecimal(value);
	}
}
