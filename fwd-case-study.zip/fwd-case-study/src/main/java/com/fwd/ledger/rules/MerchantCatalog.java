package com.fwd.ledger.rules;

import com.fwd.ledger.domain.TextNormalizer;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

public final class MerchantCatalog {

	private record Entry(String name, String category) {
	}

	private final List<Entry> entries;

	public MerchantCatalog(List<MerchantRule> rules) {
		this.entries = rules.stream()
				.map(r -> new Entry(TextNormalizer.normalize(r.name()), r.category()))
				.filter(e -> !e.name().isEmpty())
				.sorted(Comparator.comparingInt((Entry e) -> e.name().length()).reversed())
				.toList();
	}

	public Optional<String> categoryFor(String merchant) {
		String normalized = TextNormalizer.normalize(merchant);
		return entries.stream()
				.filter(e -> normalized.startsWith(e.name()))
				.findFirst()
				.map(Entry::category);
	}
}
