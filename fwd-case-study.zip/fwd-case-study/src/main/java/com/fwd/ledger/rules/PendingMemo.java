package com.fwd.ledger.rules;

import com.fwd.ledger.domain.TextNormalizer;

public final class PendingMemo {

	private final String prefix;

	public PendingMemo(String prefix) {
		this.prefix = TextNormalizer.normalize(prefix);
	}

	public boolean matches(String memo) {
		return TextNormalizer.normalize(memo).startsWith(prefix);
	}
}
