package com.fwd.ledger.domain;

import java.util.Locale;

public enum TransactionType {
	PURCHASE, REFUND, DEPOSIT, TRANSFER;

	public String csvValue() {
		return name().toLowerCase(Locale.ROOT);
	}
}
