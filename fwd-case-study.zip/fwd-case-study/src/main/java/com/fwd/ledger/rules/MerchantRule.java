package com.fwd.ledger.rules;

import jakarta.validation.constraints.NotBlank;

public record MerchantRule(@NotBlank String name, @NotBlank String category) {
}
