package com.fwd.ledger.rules;

import com.fwd.ledger.domain.Account;
import com.fwd.ledger.domain.FeedEntry;
import com.fwd.ledger.domain.LedgerLine;
import com.fwd.ledger.domain.RawTransaction;
import com.fwd.ledger.domain.ReviewReason;
import com.fwd.ledger.domain.TransactionType;
import java.math.BigDecimal;
import java.util.EnumSet;
import java.util.Optional;
import java.util.Set;

public final class TransactionClassifier {

	private final MerchantCatalog catalog;
	private final TransferMatcher matcher;
	private final PendingMemo pendingMemo;
	private final Categories categories;

	public TransactionClassifier(MerchantCatalog catalog, TransferMatcher matcher, PendingMemo pendingMemo,
			Categories categories) {
		this.catalog = catalog;
		this.matcher = matcher;
		this.pendingMemo = pendingMemo;
		this.categories = categories;
	}

	public LedgerLine classify(FeedEntry entry) {
		RawTransaction tx = entry.transaction();
		Optional<String> merchantCategory = catalog.categoryFor(tx.merchant());

		// Step 1: type and category
		TransactionType type;
		String category;
		if (matcher.fits(tx.memo(), tx.account(), tx.amount()) && merchantCategory.isEmpty()) {
			type = TransactionType.TRANSFER;
			category = categories.transfer();
		}
		else {
			type = typeFor(tx.account(), tx.amount());
			category = categoryFor(tx.account(), merchantCategory);
		}

		// Step 2: review checks, five independent ones, on every line
		Set<ReviewReason> reasons = EnumSet.noneOf(ReviewReason.class);
		if (tx.account() == Account.UNKNOWN) {
			reasons.add(ReviewReason.UNKNOWN_ACCOUNT);
		}
		if (type != TransactionType.TRANSFER && merchantCategory.isEmpty()) {
			reasons.add(ReviewReason.UNKNOWN_MERCHANT);
		}
		if (matcher.contains(tx.memo()) && merchantCategory.isPresent()) {
			reasons.add(ReviewReason.TRANSFER_PATTERN_ON_LISTED_MERCHANT);
		}
		if (entry.sameBatchConflict()) {
			reasons.add(ReviewReason.SAME_BATCH_CONFLICT);
		}
		if (pendingMemo.matches(tx.memo())) {
			reasons.add(ReviewReason.PENDING_NOT_POSTED);
		}
		return new LedgerLine(tx.id(), tx.date(), type, category, tx.amount(), reasons);
	}

	private static TransactionType typeFor(Account account, BigDecimal amount) {
		if (amount.signum() >= 0) {
			return TransactionType.PURCHASE;
		}
		return account == Account.CARD ? TransactionType.REFUND : TransactionType.DEPOSIT;
	}

	private String categoryFor(Account account, Optional<String> merchantCategory) {
		if (account == Account.UNKNOWN) {
			return categories.uncategorized();
		}
		return merchantCategory.orElse(categories.uncategorized());
	}
}
