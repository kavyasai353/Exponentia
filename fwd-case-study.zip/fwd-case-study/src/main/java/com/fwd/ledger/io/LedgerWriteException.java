package com.fwd.ledger.io;

import java.io.IOException;
import java.nio.file.Path;

public final class LedgerWriteException extends IOException {

	private static final long serialVersionUID = 1L;

	public LedgerWriteException(Path target, IOException cause) {
		super("Could not write ledger " + target + ": " + CauseMessage.of(cause), cause);
	}
}
