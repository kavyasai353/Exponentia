package com.fwd.ledger.domain;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Collections;
import java.util.EnumSet;
import java.util.Set;

public record LedgerLine(String transactionId, LocalDate date, TransactionType type, String category,
		BigDecimal amount, Set<ReviewReason> reviewReasons) {

	public LedgerLine {
		EnumSet<ReviewReason> copy = EnumSet.noneOf(ReviewReason.class);
		copy.addAll(reviewReasons);
		reviewReasons = Collections.unmodifiableSet(copy);
	}

	public boolean needsReview() {
		return !reviewReasons.isEmpty();
	}
}
