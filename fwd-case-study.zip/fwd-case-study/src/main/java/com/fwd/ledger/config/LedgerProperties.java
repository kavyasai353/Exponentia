package com.fwd.ledger.config;

import com.fwd.ledger.domain.Account;
import com.fwd.ledger.domain.TextNormalizer;
import com.fwd.ledger.rules.Categories;
import com.fwd.ledger.rules.MerchantRule;
import com.fwd.ledger.rules.TransferPatternRule;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

@Validated
@ConfigurationProperties("ledger")
public record LedgerProperties(@Valid @NotNull Categories categories,
		@NotEmpty List<@Valid @NotNull TransferPatternRule> transferPatterns,
		@NotBlank String pendingMemoPrefix,
		@NotEmpty List<@Valid @NotNull MerchantRule> merchants) {

	public LedgerProperties {
		if (merchants != null) {
			Set<String> seen = new HashSet<>();
			for (MerchantRule rule : merchants) {
				if (rule == null) {
					continue;
				}
				String normalized = TextNormalizer.normalize(rule.name());
				if (!seen.add(normalized)) {
					throw new IllegalArgumentException("Duplicate merchant name in ledger.merchants: " + normalized);
				}
			}
			merchants = List.copyOf(merchants);
		}
		if (transferPatterns != null) {
			for (TransferPatternRule rule : transferPatterns) {
				if (rule != null && rule.account() == Account.UNKNOWN) {
					throw new IllegalArgumentException(
							"Transfer pattern '" + rule.text() + "' must use account card or bank");
				}
			}
			transferPatterns = List.copyOf(transferPatterns);
		}
	}
}
