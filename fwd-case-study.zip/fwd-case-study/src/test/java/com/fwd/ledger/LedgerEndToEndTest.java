package com.fwd.ledger;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.io.TempDir;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.test.system.CapturedOutput;
import org.springframework.boot.test.system.OutputCaptureExtension;
import org.springframework.context.ConfigurableApplicationContext;

@ExtendWith(OutputCaptureExtension.class)
class LedgerEndToEndTest {

	private static final Path FEEDS = Paths.get("src/test/resources/feeds");

	@TempDir
	Path tmp;

	private static int run(Path in, Path out) {
		try (ConfigurableApplicationContext ctx = new SpringApplicationBuilder(LedgerApplication.class)
				.run("--input=" + in, "--output=" + out)) {
			return SpringApplication.exit(ctx);
		}
	}

	@Test
	void sampleFeedProducesExpectedLedger() throws IOException {
		Path out = tmp.resolve("ledger_lines.csv");
		int code = run(FEEDS.resolve("transactions.csv"), out);

		assertThat(code).isZero();
		byte[] actual = Files.readAllBytes(out);
		byte[] first15 = Files.readAllBytes(FEEDS.resolve("expected_first_15.csv"));
		// the case study's own acceptance check: the provided first 15 rows
		assertThat(actual).startsWith(first15);
		assertThat(actual).isEqualTo(Files.readAllBytes(FEEDS.resolve("expected_ledger_lines.csv")));
	}

	@Test
	void invalidFeedFailsWithRowErrorsAndWritesNothing(CapturedOutput output) {
		Path out = tmp.resolve("ledger_lines.csv");
		int code = run(FEEDS.resolve("invalid_feed.csv"), out);

		assertThat(code).isEqualTo(1);
		assertThat(output.getErr()).contains("line 3: amount").contains("line 4: id");
		assertThat(out).doesNotExist();
	}

	@Test
	void outputSameAsInputIsRejectedAndInputUntouched(CapturedOutput output) throws IOException {
		Path in = tmp.resolve("transactions.csv");
		Files.copy(FEEDS.resolve("transactions.csv"), in);
		byte[] before = Files.readAllBytes(in);

		int code = run(in, in);

		assertThat(code).isEqualTo(1);
		assertThat(output.getErr()).contains("--output must not be the same file as --input");
		assertThat(Files.readAllBytes(in)).isEqualTo(before);
	}
}
