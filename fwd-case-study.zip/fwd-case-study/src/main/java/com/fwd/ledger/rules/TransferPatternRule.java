package com.fwd.ledger.rules;

import com.fwd.ledger.domain.Account;
import com.fwd.ledger.domain.Direction;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record TransferPatternRule(@NotBlank String text, @NotNull Account account,
		@NotNull Direction direction) {
}
