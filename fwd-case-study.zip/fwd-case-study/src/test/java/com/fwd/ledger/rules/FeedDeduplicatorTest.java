package com.fwd.ledger.rules;

import static org.assertj.core.api.Assertions.assertThat;

import com.fwd.ledger.domain.Account;
import com.fwd.ledger.domain.DedupResult;
import com.fwd.ledger.domain.RawTransaction;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import org.junit.jupiter.api.Test;

class FeedDeduplicatorTest {

	private final FeedDeduplicator dedup = new FeedDeduplicator();

	private RawTransaction row(String id, long batch, String amount) {
		return new RawTransaction(id, batch, LocalDate.of(2026, 8, 1), Account.CARD, "card",
				"M", "memo", new BigDecimal(amount));
	}

	@Test
	void highestBatchWinsWhenLater() {
		DedupResult r = dedup.deduplicate(List.of(row("a", 1, "1.00"), row("a", 2, "62.40")));
		assertThat(r.entries()).hasSize(1);
		assertThat(r.entries().get(0).transaction().amount()).isEqualByComparingTo("62.40");
		assertThat(r.entries().get(0).sameBatchConflict()).isFalse();
		assertThat(r.duplicatesDropped()).isEqualTo(1);
	}

	@Test
	void highestBatchWinsWhenEarlierInFile() {
		DedupResult r = dedup.deduplicate(List.of(row("a", 2, "62.40"), row("a", 1, "1.00")));
		assertThat(r.entries()).hasSize(1);
		assertThat(r.entries().get(0).transaction().syncBatch()).isEqualTo(2);
		assertThat(r.entries().get(0).sameBatchConflict()).isFalse();
	}

	@Test
	void outputFollowsFirstAppearance() {
		DedupResult r = dedup.deduplicate(List.of(
				row("a", 1, "1.00"), row("b", 1, "2.00"), row("a", 2, "3.00"), row("c", 1, "4.00")));
		assertThat(r.entries()).extracting(e -> e.transaction().id()).containsExactly("a", "b", "c");
		assertThat(r.duplicatesDropped()).isEqualTo(1);
	}

	@Test
	void sameBatchTieKeepsLastAndFlags() {
		DedupResult r = dedup.deduplicate(List.of(row("a", 1, "1.00"), row("a", 1, "2.00")));
		assertThat(r.entries()).hasSize(1);
		assertThat(r.entries().get(0).transaction().amount()).isEqualByComparingTo("2.00");
		assertThat(r.entries().get(0).sameBatchConflict()).isTrue();
	}

	@Test
	void identicalCopiesInTopBatchAreFlagged() {
		DedupResult r = dedup.deduplicate(List.of(row("a", 1, "1.00"), row("a", 1, "1.00")));
		assertThat(r.entries().get(0).sameBatchConflict()).isTrue();
	}

	@Test
	void tieInLowerBatchIsNotAConflict() {
		DedupResult r = dedup.deduplicate(List.of(row("a", 1, "1.00"), row("a", 1, "2.00"), row("a", 2, "3.00")));
		assertThat(r.entries()).hasSize(1);
		assertThat(r.entries().get(0).sameBatchConflict()).isFalse();
		assertThat(r.duplicatesDropped()).isEqualTo(2);
	}

	@Test
	void emptyInput() {
		DedupResult r = dedup.deduplicate(List.of());
		assertThat(r.entries()).isEmpty();
		assertThat(r.duplicatesDropped()).isZero();
	}
}
