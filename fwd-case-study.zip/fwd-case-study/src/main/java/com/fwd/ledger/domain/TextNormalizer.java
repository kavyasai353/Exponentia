package com.fwd.ledger.domain;

import java.util.Locale;
import java.util.regex.Pattern;

public final class TextNormalizer {

	private static final Pattern WHITESPACE = Pattern.compile("\\s+");

	private TextNormalizer() {
	}

	public static String normalize(String s) {
		if (s == null) {
			return "";
		}
		return WHITESPACE.matcher(s.trim()).replaceAll(" ").toUpperCase(Locale.ROOT);
	}
}
