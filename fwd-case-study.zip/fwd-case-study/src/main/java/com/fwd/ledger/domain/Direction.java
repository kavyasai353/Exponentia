package com.fwd.ledger.domain;

import java.math.BigDecimal;

public enum Direction {
	OUT, IN;

	public boolean matches(BigDecimal amount) {
		return switch (this) {
			case OUT -> amount.signum() > 0;
			case IN -> amount.signum() < 0;
		};
	}
}
