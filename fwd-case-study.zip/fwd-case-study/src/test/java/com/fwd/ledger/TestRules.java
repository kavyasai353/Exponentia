package com.fwd.ledger;

import com.fwd.ledger.config.LedgerProperties;
import com.fwd.ledger.io.LedgerCsvWriter;
import com.fwd.ledger.io.TransactionCsvReader;
import com.fwd.ledger.rules.FeedDeduplicator;
import com.fwd.ledger.rules.MerchantCatalog;
import com.fwd.ledger.rules.PendingMemo;
import com.fwd.ledger.rules.TransactionClassifier;
import com.fwd.ledger.rules.TransferMatcher;
import java.io.IOException;
import java.nio.file.Path;
import java.util.List;
import org.springframework.boot.context.properties.bind.Binder;
import org.springframework.boot.context.properties.source.ConfigurationPropertySources;
import org.springframework.boot.env.YamlPropertySourceLoader;
import org.springframework.core.env.PropertySource;
import org.springframework.core.io.FileSystemResource;

/** Loads the shipped application.yml without starting a Spring context. */
public final class TestRules {

	private static final Path YAML = Path.of("src/main/resources/application.yml");
	private static LedgerProperties cached;

	private TestRules() {
	}

	public static synchronized LedgerProperties load() {
		if (cached == null) {
			try {
				List<PropertySource<?>> sources = new YamlPropertySourceLoader()
						.load("application", new FileSystemResource(YAML));
				cached = new Binder(ConfigurationPropertySources.from(sources))
						.bind("ledger", LedgerProperties.class)
						.get();
			}
			catch (IOException e) {
				throw new IllegalStateException("Cannot read " + YAML, e);
			}
		}
		return cached;
	}

	public static MerchantCatalog merchantCatalog() {
		return new MerchantCatalog(load().merchants());
	}

	public static TransferMatcher transferMatcher() {
		return new TransferMatcher(load().transferPatterns());
	}

	public static PendingMemo pendingMemo() {
		return new PendingMemo(load().pendingMemoPrefix());
	}

	public static TransactionClassifier classifier() {
		return new TransactionClassifier(merchantCatalog(), transferMatcher(), pendingMemo(), load().categories());
	}

	public static LedgerService service() {
		return new LedgerService(new TransactionCsvReader(), new FeedDeduplicator(), classifier(),
				new LedgerCsvWriter());
	}
}
