package com.fwd.ledger.io;

import java.util.List;

public final class FeedValidationException extends Exception {

	private static final long serialVersionUID = 1L;

	private final transient List<RowError> errors;

	public FeedValidationException(List<RowError> errors) {
		super(buildMessage(errors));
		this.errors = List.copyOf(errors);
	}

	public List<RowError> errors() {
		return errors;
	}

	private static String buildMessage(List<RowError> errors) {
		StringBuilder sb = new StringBuilder("Invalid feed: ").append(errors.size())
				.append(errors.size() == 1 ? " bad row" : " bad rows");
		for (RowError e : errors) {
			sb.append(System.lineSeparator()).append(e);
		}
		return sb.toString();
	}
}
