package com.fwd.ledger.rules;

import static org.assertj.core.api.Assertions.assertThat;

import com.fwd.ledger.TestRules;
import com.fwd.ledger.domain.Account;
import com.fwd.ledger.domain.FeedEntry;
import com.fwd.ledger.domain.LedgerLine;
import com.fwd.ledger.domain.RawTransaction;
import com.fwd.ledger.domain.ReviewReason;
import com.fwd.ledger.domain.TransactionType;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.EnumSet;
import java.util.Set;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;

class TransactionClassifierTest {

	private static final Set<ReviewReason> NONE = Set.of();

	private final TransactionClassifier classifier = TestRules.classifier();

	private record Row(String label, String account, String amount, String merchant, String memo,
			boolean conflict, TransactionType type, String category, Set<ReviewReason> reasons) {

		@Override
		public String toString() {
			return label;
		}
	}

	private static LedgerLine classify(String id, String accountRaw, String amount, String merchant, String memo,
			boolean conflict, TransactionClassifier classifier) {
		RawTransaction tx = new RawTransaction(id, 1, LocalDate.of(2026, 8, 1), Account.fromFeed(accountRaw),
				accountRaw, merchant, memo, new BigDecimal(amount));
		return classifier.classify(conflict ? FeedEntry.conflicted(tx) : FeedEntry.fresh(tx));
	}

	@Test
	void lineCarriesIdDateAndAmount() {
		LedgerLine line = classify("txn_7", "card", "62.40", "SYSCO 1", "SYSCO 1", false, classifier);
		assertThat(line.transactionId()).isEqualTo("txn_7");
		assertThat(line.date()).isEqualTo(LocalDate.of(2026, 8, 1));
		assertThat(line.amount()).isEqualByComparingTo("62.40");
	}

	static Stream<Row> rows() {
		return Stream.of(
				new Row("sample: card purchase", "card", "10.00", "SYSCO PHILA 8827", "SYSCO PHILA 8827", false,
						TransactionType.PURCHASE, "Food & beverage", NONE),
				new Row("sample: card refund", "card", "-184.20", "SYSCO PHILA 8827", "SYSCO CREDIT SHORTED DELIVERY",
						false, TransactionType.REFUND, "Food & beverage", NONE),
				new Row("sample: refund, unknown merchant", "card", "-41.99", "AMZN MKTP US*7Q1P2",
						"AMZN MKTP US*7Q1P2", false, TransactionType.REFUND, "Uncategorized",
						EnumSet.of(ReviewReason.UNKNOWN_MERCHANT)),
				new Row("sample: bank rent", "bank", "6500.00", "MAINLINE PROPERTIES LLC",
						"ACH PAYMENT MAINLINE PROPERTIES", false, TransactionType.PURCHASE, "Rent", NONE),
				new Row("sample: payment to card", "bank", "4850.00", "ONLINE PAYMENT TO CARD 4421",
						"ONLINE PAYMENT TO CARD 4421", false, TransactionType.TRANSFER, "Transfer", NONE),
				new Row("sample: payment thank you", "card", "-4850.00", "PAYMENT RECEIVED",
						"ONLINE PAYMENT - THANK YOU", false, TransactionType.TRANSFER, "Transfer", NONE),
				new Row("sample: payout deposit", "bank", "-6120.30", "TOAST PAYOUT", "TOAST INC DAILY PAYOUT", false,
						TransactionType.DEPOSIT, "Card sales", NONE),
				new Row("row 1", "card", "10.00", "SYSCO 1", "SYSCO 1", false,
						TransactionType.PURCHASE, "Food & beverage", NONE),
				new Row("row 2", "savings", "10.00", "ACME", "TRANSFER TO SAVINGS", false,
						TransactionType.PURCHASE, "Uncategorized",
						EnumSet.of(ReviewReason.UNKNOWN_ACCOUNT, ReviewReason.UNKNOWN_MERCHANT)),
				new Row("row 3", "savings", "-10.00", "SYSCO 1", "SYSCO 1", false,
						TransactionType.DEPOSIT, "Uncategorized", EnumSet.of(ReviewReason.UNKNOWN_ACCOUNT)),
				new Row("row 4", "bank", "10.00", "ONLINE PMT", "PAYMENT TO CARD 4421", false,
						TransactionType.TRANSFER, "Transfer", NONE),
				new Row("row 5", "bank", "10.00", "ONLINE PMT", "ONLINE PAYMENT - THANK YOU", false,
						TransactionType.PURCHASE, "Uncategorized", EnumSet.of(ReviewReason.UNKNOWN_MERCHANT)),
				new Row("row 6", "bank", "0.00", "ONLINE PMT", "PAYMENT TO CARD 4421", false,
						TransactionType.PURCHASE, "Uncategorized", EnumSet.of(ReviewReason.UNKNOWN_MERCHANT)),
				new Row("row 7", "card", "-10.00", "SYSCO 1", "TRANSFER FROM SAVINGS", false,
						TransactionType.REFUND, "Food & beverage",
						EnumSet.of(ReviewReason.TRANSFER_PATTERN_ON_LISTED_MERCHANT)),
				new Row("row 8", "card", "10.00", "SYSCO 1", "PENDING - SYSCO", true,
						TransactionType.PURCHASE, "Food & beverage",
						EnumSet.of(ReviewReason.PENDING_NOT_POSTED, ReviewReason.SAME_BATCH_CONFLICT)),
				new Row("row 9", "card", "-10.00", "PAYMENT RECEIVED", "PENDING - ONLINE PAYMENT - THANK YOU",
						false, TransactionType.TRANSFER, "Transfer", EnumSet.of(ReviewReason.PENDING_NOT_POSTED)),
				new Row("row 10", "bank", "10.00", "ACME", "ACME", true,
						TransactionType.PURCHASE, "Uncategorized",
						EnumSet.of(ReviewReason.UNKNOWN_MERCHANT, ReviewReason.SAME_BATCH_CONFLICT)),
				new Row("row 11", "bank", "-10.00", "TOAST PAYOUT", "TOAST INC DAILY PAYOUT", false,
						TransactionType.DEPOSIT, "Card sales", NONE),
				new Row("unknown account, transfer text, listed merchant, positive", "savings", "10.00", "SYSCO 1",
						"TRANSFER TO SAVINGS", false, TransactionType.PURCHASE, "Uncategorized",
						EnumSet.of(ReviewReason.UNKNOWN_ACCOUNT,
								ReviewReason.TRANSFER_PATTERN_ON_LISTED_MERCHANT)),
				new Row("unknown account, transfer text, listed merchant, negative", "savings", "-10.00", "SYSCO 1",
						"TRANSFER FROM SAVINGS", false, TransactionType.DEPOSIT, "Uncategorized",
						EnumSet.of(ReviewReason.UNKNOWN_ACCOUNT,
								ReviewReason.TRANSFER_PATTERN_ON_LISTED_MERCHANT)));
	}

	@ParameterizedTest(name = "{0}")
	@MethodSource("rows")
	void classifiesRow(Row row) {
		LedgerLine line = classify("t", row.account(), row.amount(), row.merchant(), row.memo(), row.conflict(),
				classifier);
		assertThat(line.type()).isEqualTo(row.type());
		assertThat(line.category()).isEqualTo(row.category());
		assertThat(line.reviewReasons()).isEqualTo(row.reasons());
		assertThat(line.needsReview()).isEqualTo(!row.reasons().isEmpty());
	}
}
