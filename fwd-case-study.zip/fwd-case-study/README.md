# Ledger: categorize a transaction feed

A small command-line app for the restaurant bookkeeper case study (EXP-412, Story 1). It reads one operator's raw card and bank feed and writes one ledger line per transaction id, with a type, a category, the signed amount and a `needs_review` flag. When it isn't sure, it flags the line instead of guessing.

## How to run it

You need JDK 21. You don't need Maven; `./mvnw` downloads the right version the first time.

Build it and run the tests:

```bash
./mvnw verify
```

Run it on the sample feed:

```bash
java -jar target/ledger.jar --input=src/test/resources/feeds/transactions.csv --output=out/ledger_lines.csv
```

You should see:

```text
Wrote 56 ledger lines to out/ledger_lines.csv: 4 need review, 4 duplicate rows dropped
```

To check the result against the full expected output (no output from `cmp` means the files are identical):

```bash
cmp out/ledger_lines.csv src/test/resources/feeds/expected_ledger_lines.csv
```

For your own feed, point `--input` and `--output` somewhere else. The app exits with 0 on success and 1 on any failure, with a one-line reason on stderr.

## How it decides

First it picks the type and category. The first row in this table that applies is the one used.

| # | When | Type | Category |
|---|---|---|---|
| 1 | A transfer pattern fits the row and the merchant isn't on the list | `transfer` | Transfer |
| 2 | The account is something other than `card` or `bank` | `deposit` if negative, else `purchase` | Uncategorized |
| 3 | Card, negative amount | `refund` | the merchant's category, else Uncategorized |
| 4 | Bank, negative amount | `deposit` | the merchant's category, else Uncategorized |
| 5 | Anything else | `purchase` | the merchant's category, else Uncategorized |

Then it runs five checks on every line, no matter which row above was used. If any of them fires, `needs_review` is `true`.

| Check | Fires when |
|---|---|
| Unknown merchant | not a transfer, and the merchant isn't on the list |
| Unknown account | the account isn't `card` or `bank` |
| Transfer wording on a known merchant | the memo contains a transfer pattern but the merchant is on the list |
| Duplicate in the same batch | the same id shows up twice in its highest sync batch |
| Still pending | the row that survived still has a `PENDING` memo |

Merchants match by prefix, ignoring case and extra spaces, so `SYSCO PHILA 8827` is SYSCO. If two list names match, the longer one wins.

## Changing the rules

Everything lives in `src/main/resources/application.yml`. Adding a merchant or a transfer pattern doesn't need a code change.

A merchant:

```yaml
    - { name: "SHELL OIL", category: "Fuel" }
```

A transfer pattern needs the text, the account it shows up on, and the direction (`out` for a positive amount, `in` for a negative one):

```yaml
    - { text: "TRANSFER TO CHECKING", account: "bank", direction: "out" }
```

One thing to watch: because matching is by prefix, a new merchant called `SYSCOMART` would quietly get SYSCO's category. Add it as its own entry and the longer name wins.

The app refuses to start if a list is empty, a value is blank, or two merchant names are the same once case and spacing are ignored.

## Errors

| Problem | What you see on stderr |
|---|---|
| Missing or repeated `--input` / `--output` | `Usage: java -jar ledger.jar --input=<transactions.csv> --output=<ledger_lines.csv>` |
| Input file doesn't exist | `Input file not found: <path>` |
| Output is the same file as the input | `--output must not be the same file as --input` |
| Bad rows | `Invalid feed: N bad rows`, then one line per problem with the line number, field and reason |
| Wrong header | a line 1 error showing the header it found and the one it expected |
| File can't be read or isn't valid CSV | `Could not read input <path>: <cause>` |
| Output can't be written | `Could not write ledger <path>: <cause>` |
| Anything unexpected | `Unexpected error: <message>`, with the stack trace in the log |

One bad row stops the whole run, and nothing is written. Every row is checked first, so you see all the problems at once instead of fixing them one run at a time.

## What I found unclear or wrong in the story

**The transfer rule, as written, books rent as a transfer.** The story says transfer memos "will say PAYMENT or TRANSFER". `txn_1022` is a $6,500 rent payment with the memo `ACH PAYMENT MAINLINE PROPERTIES`. Taken literally, that rent becomes a transfer with `needs_review = false`, and the expense disappears from the books with nobody asked to look. So I don't match on the bare words. I match specific phrases (`PAYMENT TO CARD`, `PAYMENT - THANK YOU`, `TRANSFER TO SAVINGS`, `TRANSFER FROM SAVINGS`). Each phrase also has to be on the right account with the right sign, so `PAYMENT - THANK YOU` only counts on the card with money coming in. Unfamiliar wording falls through and gets flagged. That's annoying for a reviewer, but it's safe.

**The rest are gaps rather than mistakes.** For each one I picked the option that flags the line instead of guessing:

- **Two rows for the same id in the same batch.** The story only says to keep the highest batch. I keep the last one in the file and flag it, because I can't tell which copy is right.
- **A pending hold that never posts.** The story assumes a later batch replaces it. If none does, booking the hold amount as final would be wrong, so a surviving `PENDING` memo gets flagged.
- **An account that's neither card nor bank** (say a savings account shows up). I write the line by sign and flag it, rather than stop the whole run.
- **Malformed rows.** The story doesn't say what to do. I fail the whole run and list every bad row, because a ledger that quietly skips a row looks complete when it isn't.
- **"Starts with" matching.** `SYSCOMART` would match SYSCO. I kept the rule as written and documented the workaround above.
- **A negative bank amount from a vendor.** The story makes every non-transfer negative bank amount a deposit, so a Home Depot refund paid back to the bank account would come out as a deposit in Repairs & maintenance. That follows the rule, but it reads oddly.

**What I'd ask before merging**

1. Does the provider send a transaction type or code alongside the memo? Spotting transfers from memo text is the weakest part of this. Every new bank brings new wording, and until someone adds a pattern its transfers sit in the review queue.
2. When a feed has a bad row, should we really fail the whole run? The alternative is to write the good rows and put the bad ones in a separate rejects file. I chose to fail because a partial ledger is risky, but it's a product call. A daily job that stops over one row will annoy someone.
3. How long can a pending hold stay pending before it should count as real? Right now it just gets flagged.
4. Should a refund that lands in the bank account be a `refund` or a `deposit`? See the Home Depot example above.
5. Does Story 3's review queue need to know *why* a line was flagged? The code already tracks the reason internally. It's just not written to the CSV, because the output columns are fixed.
6. Is the CRLF line ending in the expected file intentional? I match it byte for byte, but if whatever reads this file doesn't care, it's one less thing to keep matching.

## Where I used AI and where I overrode it

I used an AI assistant throughout, but I treated it like a fast junior team with good reviewers, not as the one making the decisions.

**Where I used it**

- **Design.** Turning the story into a design doc, then having separate AI reviewers read it fresh, five times, each with a different job: simplicity, contradictions, whether a newcomer could follow it, the critic pass, and "could someone build this without guessing". They found real bugs before any code existed.
- **Code and tests.** Writing most of them, in small tasks against a fixed spec: domain and rules first, then the CSV reading and writing, then the end-to-end tests. I re-ran and read every task before accepting it.
- **Boilerplate.** The project scaffold, and later a code-review pass that led to a cleanup: the type/category if-else became two small decisions, a package cycle was removed, and error handling was tightened.

**Where I didn't trust it**

The case study only gives the expected output for the first 15 rows. I had the AI work out rows 16 to 56 from the rules, without running any code. Then I worked them out separately myself and compared the two. All 56 agreed, and that file is now the answer key for the end-to-end test. I also planted two bugs on purpose, a hardcoded `"Sysco"` and refunds turned into purchases, to make sure the tests actually fail when they should. Both were caught.

**Where I overrode it**

- **It told me to cut the safe file write and the config validation**, as over-engineering for a take-home. I kept both. The write is about five lines, and without it a crash halfway through leaves a half-written ledger. The validation catches two merchant entries with the same name and different categories. Without it, which one wins would depend on the order of the list, silently.
- **It told me to drop the test that scans the source for hardcoded merchant names**, calling it a test of discipline, not behavior. I kept it, because "nothing hardcoded" was a requirement and I wanted it enforced rather than promised. I did narrow it to merchant names and transfer phrases, so it doesn't trip on everyday words like "Rent".
- **It suggested a strategy-pattern rule table for the classifier.** For five branches, that's more structure than the problem needs. I took the smaller fix: one guard for transfers, then two short methods.
- **It suggested unit tests use small made-up rule sets.** I kept them on the real `application.yml`, so the tests check the rules we actually ship.
- **It wanted to delete the "first 15 rows match" assertion as redundant.** It is redundant with the full-file check, but it's the case study's own acceptance test, so it stays, with a comment saying so.
- **The design workflow wanted me to approve every trade-off one question at a time.** After a few rounds I stopped that and made the calls myself, writing down each one with the options I turned down.

And one case where it was right and I was wrong. Early on I decided not to check the account and sign on transfer patterns, to keep things small. Two different reviewers later flagged the same hole on their own: `PAYMENT - THANK YOU` on a bank row would still be booked as an unflagged transfer. I reversed my call. The same review also caught the pending-hold case, which I hadn't thought of. It never shows up in the sample data, because every pending hold there gets posted later.

## What I'd do next

- Write the review reason out as a column once Story 3 needs it.
- Only validate rows that survive dedup, so a garbled pending row that a later batch replaces doesn't block the run. I held off because deciding a row was replaced means trusting the id and batch of a row we already know is broken.
- Story 2 (splitting a transaction across two categories), Story 3 (the review queue), and the LLM step.
