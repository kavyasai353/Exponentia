package com.fwd.ledger.rules;

import static org.assertj.core.api.Assertions.assertThat;

import com.fwd.ledger.TestRules;
import org.junit.jupiter.api.Test;

class PendingMemoTest {

	private final PendingMemo pending = TestRules.pendingMemo();

	@Test
	void pendingIsPrefixOnly() {
		assertThat(pending.matches("PENDING - SYSCO")).isTrue();
		assertThat(pending.matches("  pending - sysco")).isTrue();
		assertThat(pending.matches("SYSCO PENDING")).isFalse();
		assertThat(pending.matches(null)).isFalse();
	}
}
