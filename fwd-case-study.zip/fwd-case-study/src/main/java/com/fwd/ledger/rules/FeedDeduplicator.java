package com.fwd.ledger.rules;

import com.fwd.ledger.domain.DedupResult;
import com.fwd.ledger.domain.FeedEntry;
import com.fwd.ledger.domain.RawTransaction;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class FeedDeduplicator {

	public DedupResult deduplicate(List<RawTransaction> rows) {
		Map<String, FeedEntry> byId = new LinkedHashMap<>();
		for (RawTransaction row : rows) {
			FeedEntry current = byId.get(row.id());
			if (current == null) {
				byId.put(row.id(), FeedEntry.fresh(row));
				continue;
			}
			long best = current.transaction().syncBatch();
			if (row.syncBatch() > best) {
				byId.put(row.id(), FeedEntry.fresh(row));
			} else if (row.syncBatch() == best) {
				byId.put(row.id(), FeedEntry.conflicted(row));
			}
		}
		List<FeedEntry> entries = new ArrayList<>(byId.values());
		return new DedupResult(entries, rows.size() - entries.size());
	}
}
