package com.fwd.ledger.config;

import com.fwd.ledger.LedgerService;
import com.fwd.ledger.cli.LedgerCommandLineRunner;
import com.fwd.ledger.io.LedgerCsvWriter;
import com.fwd.ledger.io.TransactionCsvReader;
import com.fwd.ledger.rules.FeedDeduplicator;
import com.fwd.ledger.rules.MerchantCatalog;
import com.fwd.ledger.rules.PendingMemo;
import com.fwd.ledger.rules.TransactionClassifier;
import com.fwd.ledger.rules.TransferMatcher;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration(proxyBeanMethods = false)
public class LedgerConfiguration {

	@Bean
	MerchantCatalog merchantCatalog(LedgerProperties properties) {
		return new MerchantCatalog(properties.merchants());
	}

	@Bean
	TransferMatcher transferMatcher(LedgerProperties properties) {
		return new TransferMatcher(properties.transferPatterns());
	}

	@Bean
	PendingMemo pendingMemo(LedgerProperties properties) {
		return new PendingMemo(properties.pendingMemoPrefix());
	}

	@Bean
	FeedDeduplicator feedDeduplicator() {
		return new FeedDeduplicator();
	}

	@Bean
	TransactionClassifier transactionClassifier(MerchantCatalog catalog, TransferMatcher matcher,
			PendingMemo pendingMemo, LedgerProperties properties) {
		return new TransactionClassifier(catalog, matcher, pendingMemo, properties.categories());
	}

	@Bean
	TransactionCsvReader transactionCsvReader() {
		return new TransactionCsvReader();
	}

	@Bean
	LedgerCsvWriter ledgerCsvWriter() {
		return new LedgerCsvWriter();
	}

	@Bean
	LedgerService ledgerService(TransactionCsvReader reader, FeedDeduplicator deduplicator,
			TransactionClassifier classifier, LedgerCsvWriter writer) {
		return new LedgerService(reader, deduplicator, classifier, writer);
	}

	@Bean
	LedgerCommandLineRunner ledgerCommandLineRunner(LedgerService service) {
		return new LedgerCommandLineRunner(service);
	}
}
