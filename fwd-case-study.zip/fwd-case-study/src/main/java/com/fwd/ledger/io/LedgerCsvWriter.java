package com.fwd.ledger.io;

import com.fwd.ledger.domain.LedgerLine;
import java.io.BufferedWriter;
import java.io.IOException;
import java.math.RoundingMode;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.List;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;

public final class LedgerCsvWriter {

	public void write(List<LedgerLine> lines, Path target) throws LedgerWriteException {
		Path temp = null;
		boolean moved = false;
		try {
			Path dir = target.toAbsolutePath().getParent();
			Files.createDirectories(dir);
			temp = Files.createTempFile(dir, ".ledger-", ".tmp");
			try (BufferedWriter writer = Files.newBufferedWriter(temp, StandardCharsets.UTF_8);
					CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT)) {
				printer.printRecord("transaction_id", "date", "type", "category", "amount", "needs_review");
				for (LedgerLine line : lines) {
					printer.printRecord(line.transactionId(), line.date(), line.type().csvValue(), line.category(),
							line.amount().setScale(2, RoundingMode.UNNECESSARY).toPlainString(),
							line.needsReview());
				}
			}
			try {
				Files.move(temp, target, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
			}
			catch (AtomicMoveNotSupportedException e) {
				Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING);
			}
			moved = true;
		}
		catch (IOException e) {
			throw new LedgerWriteException(target, e);
		}
		finally {
			if (temp != null && !moved) {
				try {
					Files.deleteIfExists(temp);
				}
				catch (IOException ignored) {
					// nothing more to do; the original failure is what gets reported
				}
			}
		}
	}
}
