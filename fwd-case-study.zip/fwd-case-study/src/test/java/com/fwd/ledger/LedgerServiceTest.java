package com.fwd.ledger;

import static org.assertj.core.api.Assertions.assertThat;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.TreeMap;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class LedgerServiceTest {

	@TempDir
	Path dir;

	@Test
	void sampleFeedGivesExpectedSummary() throws Exception {
		Path out = dir.resolve("out.csv");
		RunSummary summary = TestRules.service().run(Path.of("src/test/resources/feeds/transactions.csv"), out);
		assertThat(summary).isEqualTo(new RunSummary(56, 4, 4, new TreeMap<>()));
		assertThat(out).exists();
	}

	@Test
	void unknownAccountValuesAreCountedPerDistinctLowerCasedValue() throws Exception {
		Path in = dir.resolve("in.csv");
		Files.writeString(in, "id,sync_batch,date,account,merchant,memo,amount\r\n"
				+ "txn_9,1,2026-08-03,savings,ACME,ACME,5.00\r\n"
				+ "txn_9,2,2026-08-03,Savings,ACME,ACME,5.00\r\n"
				+ "txn_10,1,2026-08-03,savings,ACME,ACME,6.00\r\n");
		RunSummary summary = TestRules.service().run(in, dir.resolve("out.csv"));
		assertThat(summary.unknownAccountValues()).containsExactlyInAnyOrderEntriesOf(Map.of("savings", 2));
		assertThat(summary.linesWritten()).isEqualTo(2);
		assertThat(summary.needsReview()).isEqualTo(2);
		assertThat(summary.duplicatesDropped()).isEqualTo(1);
	}
}
