package com.fwd.ledger.io;

public record RowError(long lineNumber, String field, String value, String reason) {

	@Override
	public String toString() {
		String shown = value == null || value.isEmpty() ? "" : " \"" + value + "\"";
		return "line " + lineNumber + ": " + field + shown + " " + reason;
	}
}
