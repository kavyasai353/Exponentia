package com.fwd.ledger;

import java.util.Collections;
import java.util.SortedMap;
import java.util.TreeMap;

public record RunSummary(int linesWritten, int needsReview, int duplicatesDropped,
		SortedMap<String, Integer> unknownAccountValues) {

	public RunSummary {
		unknownAccountValues = Collections.unmodifiableSortedMap(new TreeMap<>(unknownAccountValues));
	}
}
