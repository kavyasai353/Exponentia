package com.fwd.ledger;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

@SpringBootApplication
@ConfigurationPropertiesScan
public class LedgerApplication {

	public static void main(String[] args) {
		System.exit(SpringApplication.exit(SpringApplication.run(LedgerApplication.class, args)));
	}

}
