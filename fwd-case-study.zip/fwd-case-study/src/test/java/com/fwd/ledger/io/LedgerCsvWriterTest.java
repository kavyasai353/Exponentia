package com.fwd.ledger.io;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.jupiter.api.Assumptions.assumeFalse;

import com.fwd.ledger.domain.LedgerLine;
import com.fwd.ledger.domain.ReviewReason;
import com.fwd.ledger.domain.TransactionType;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.PosixFilePermissions;
import java.time.LocalDate;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class LedgerCsvWriterTest {

	private static final String EXPECTED = "transaction_id,date,type,category,amount,needs_review\r\n"
			+ "txn_1,2026-08-03,purchase,Rent,300.00,false\r\n"
			+ "txn_2,2026-08-04,refund,Uncategorized,-41.99,true\r\n";

	@TempDir
	Path dir;

	private final LedgerCsvWriter writer = new LedgerCsvWriter();

	private static List<LedgerLine> lines() {
		return List.of(
				new LedgerLine("txn_1", LocalDate.of(2026, 8, 3), TransactionType.PURCHASE, "Rent",
						new BigDecimal("300"), Set.of()),
				new LedgerLine("txn_2", LocalDate.of(2026, 8, 4), TransactionType.REFUND, "Uncategorized",
						new BigDecimal("-41.99"), Set.of(ReviewReason.UNKNOWN_MERCHANT)));
	}

	@Test
	void writesHeaderAndLinesWithCrlf() throws Exception {
		Path out = dir.resolve("out.csv");
		writer.write(lines(), out);
		assertThat(Files.readAllBytes(out)).isEqualTo(EXPECTED.getBytes(StandardCharsets.UTF_8));
	}

	@Test
	void replacesExistingFileAndLeavesNoTempFile() throws Exception {
		Path out = dir.resolve("out.csv");
		Files.writeString(out, "old content");
		writer.write(lines(), out);
		assertThat(Files.readString(out)).isEqualTo(EXPECTED);
		try (Stream<Path> files = Files.list(dir)) {
			assertThat(files.map(p -> p.getFileName().toString())).containsExactly("out.csv");
		}
	}

	@Test
	void createsMissingDirectory() throws Exception {
		Path out = dir.resolve("a/b/out.csv");
		writer.write(lines(), out);
		assertThat(out).exists();
	}

	@Test
	void negativeZeroIsWrittenAsZero() throws Exception {
		Path out = dir.resolve("out.csv");
		writer.write(List.of(new LedgerLine("txn_1", LocalDate.of(2026, 8, 3), TransactionType.PURCHASE, "Rent",
				new BigDecimal("-0.00"), Set.of())), out);
		assertThat(Files.readString(out)).contains(",0.00,false");
	}

	@Test
	void unwritableDirectoryGivesLedgerWriteExceptionAndNoTarget() throws Exception {
		Path locked = Files.createDirectory(dir.resolve("locked"));
		Path out = locked.resolve("out.csv");
		Files.setPosixFilePermissions(locked, PosixFilePermissions.fromString("r-xr-xr-x"));
		try {
			assumeFalse(Files.isWritable(locked), "directory stays writable (running as root?)");
			assertThatThrownBy(() -> writer.write(lines(), out)).isInstanceOf(LedgerWriteException.class)
					.hasMessageStartingWith("Could not write ledger " + out + ": ");
			assertThat(out).doesNotExist();
			try (Stream<Path> files = Files.list(locked)) {
				assertThat(files).isEmpty();
			}
		}
		finally {
			Files.setPosixFilePermissions(locked, PosixFilePermissions.fromString("rwxr-xr-x"));
		}
	}
}
