package com.fwd.ledger;

import static org.assertj.core.api.Assertions.assertThat;

import com.fwd.ledger.config.LedgerProperties;
import com.fwd.ledger.domain.TextNormalizer;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;
import org.junit.jupiter.api.Test;

class NoHardcodedRulesTest {

	private static final Path MAIN = Paths.get("src/main/java");

	// Comments and literals in one pass, so "//" inside a string is not taken for a comment.
	private static final Pattern TOKENS = Pattern.compile(
			"\"\"\"[\\s\\S]*?\"\"\"|\"(?:[^\"\\\\]|\\\\.)*\"|//[^\\n]*|/\\*[\\s\\S]*?\\*/");

	@Test
	void noRuleValueAppearsInJavaSource() throws IOException {
		List<String> rules = ruleTexts();
		assertThat(rules).isNotEmpty();
		List<Path> files;
		try (Stream<Path> s = Files.walk(MAIN)) {
			files = s.filter(p -> p.toString().endsWith(".java")).toList();
		}
		assertThat(files).isNotEmpty();
		List<String> hits = new ArrayList<>();
		for (Path f : files) {
			hits.addAll(scan(f.toString(), Files.readString(f), rules));
		}
		assertThat(hits).as("rule values hard-coded in source").isEmpty();
	}

	@Test
	void scannerReportsMerchantNameLiteral() {
		List<String> hits = scan("Fake.java",
				"class Fake { String s = \"sysco phila\"; // \"HOME DEPOT\" in a comment\n }",
				List.of("SYSCO", "HOME DEPOT"));
		assertThat(hits).hasSize(1);
		assertThat(hits.get(0)).contains("Fake.java").contains("SYSCO");
	}

	private static List<String> scan(String file, String source, List<String> rules) {
		List<String> hits = new ArrayList<>();
		Matcher m = TOKENS.matcher(source);
		while (m.find()) {
			String t = m.group();
			if (!t.startsWith("\"")) {
				continue; // comment
			}
			String value = TextNormalizer.normalize(t);
			for (String r : rules) {
				if (value.contains(r)) {
					hits.add(file + ": literal " + t + " contains rule value '" + r + "'");
				}
			}
		}
		return hits;
	}

	private static List<String> ruleTexts() {
		LedgerProperties props = TestRules.load();
		List<String> out = new ArrayList<>();
		props.merchants().forEach(m -> out.add(TextNormalizer.normalize(m.name())));
		props.transferPatterns().forEach(p -> out.add(TextNormalizer.normalize(p.text())));
		return out;
	}
}
