package com.fwd.ledger.domain;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

class TextNormalizerTest {

	@Test
	void trimsCollapsesAndUpperCases() {
		assertThat(TextNormalizer.normalize("  sysco   phila ")).isEqualTo("SYSCO PHILA");
	}

	@Test
	void nullBecomesEmpty() {
		assertThat(TextNormalizer.normalize(null)).isEmpty();
	}

	@Test
	void tabsAndNewlinesCollapse() {
		assertThat(TextNormalizer.normalize("a\t\n b")).isEqualTo("A B");
	}
}
